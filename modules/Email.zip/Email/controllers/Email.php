<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email extends MX_Controller {

        public function __construct()
        {
                // Call the CI_Model constructor
                parent::__construct();
                $this->murl = '/modules/'.$this->uri->segment(1).'/';
        }

	public function index()
	{
            echo "MASUK EMAIL =".date('Y-m-d H:i:s');
            // Set SMTP Configuration
            $emailConfig = array(
               'protocol' => 'smtp',
                'smtp_host' => 'ssl://smtp.googlemail.com',
                'smtp_port' => 465,
                'smtp_user' => 'webuppmpolban@gmail.com',
                'smtp_pass' => 'nanaasephandoko',
                'mailtype'  => 'html',
                'charset'   => 'iso-8859-1'
            );

            // Set your email information
            $from = array('email' => 'webuppmpolban@gmail.com', 'name' => 'Handoko');
            $to = array('hanupas@gmail.com', 'simpanhan@gmail.com');
            $subject = 'Hai';

            $message = 'Hai';
            // Load CodeIgniter Email library
            $this->load->library('email', $emailConfig);

            // Sometimes you have to set the new line character for better result
            $this->email->set_newline("rn");
            // Set email preferences
            $this->email->from($from['email'], $from['name']);
            $this->email->to($to);

            $this->email->subject($subject);
            $this->email->message($message);
            // Ready to send email and check whether the email was successfully sent

            if (!$this->email->send()) {
                // Raise error message
                show_error($this->email->print_debugger());
            }
            else {
                // Show success notification or other things here
                echo 'Success to send email';
            }
	}
        
        public function try1(){
                        echo "MASUK TRY 1 =".date('Y-m-d H:i:s');
            $config = array();
                $config['useragent']           = "CodeIgniter";
                $config['mailpath']            = "/usr/bin/sendmail"; // or "/usr/sbin/sendmail"
                $config['protocol']            = "smtp";
                $config['smtp_host']           = "localhost";
                $config['smtp_port']           = "25";
                $config['mailtype'] = 'html';
                $config['charset']  = 'utf-8';
                $config['newline']  = "\r\n";
                $config['wordwrap'] = TRUE;

                $this->load->library('email');

                $this->email->initialize($config);

                $this->email->from('webuppmpolban@gmail.com', 'admin');
                $this->email->to('hanupas@gmail.com');
                $this->email->subject('Registration Verification: Continuous Imapression');
                $msg = "Thanks for signing up!Your account has been created, 
            you can login with your credentials after you have activated your account by pressing the url below.
            Please click this link to activate your account:<a href='.base_url('user/verify').>Click Here</a>";

            $this->email->message($msg);   
            //$this->email->message($this->load->view('email/'.$type.'-html', $data, TRUE));

            $this->email->send();
        }
        
}
